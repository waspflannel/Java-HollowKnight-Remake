<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="Main" tilewidth="16" tileheight="16" tilecount="4096" columns="64">
 <image source="mainlevbuild.png" width="1024" height="1024"/>
</tileset>
