<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="SKY" tilewidth="16" tileheight="16" tilecount="64" columns="8">
 <image source="18.png" width="128" height="128"/>
</tileset>
